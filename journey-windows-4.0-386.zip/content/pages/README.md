# content/pages
Place your custom files here (e.g. in sub folders) to serve them with Journey.

Let's say you have a page (html, css) in content/pages/mypage/. That page will be reachable under yourblog.url/pages/mypage.