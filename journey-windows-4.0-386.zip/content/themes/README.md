# content/themes

Place your themes here (in subfolders) to be able to select them from the admin interface.

## More about themes

The Promenade theme is included by default to make journey work out of the box. However, it is only intended to be used on a one author, personal website.

For a fully fledged, multiple author blog experience try the [Casper](https://github.com/TryGhost/Casper) theme from the makers of Ghost.

[Download it](https://github.com/TryGhost/Casper/releases) and place the Casper directory in your path_to_journey/content/themes/ folder. Then select Casper from your admin panel under Settings/Blog.
