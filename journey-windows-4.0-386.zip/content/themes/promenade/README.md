# Promenade
A one author theme for the Ghost blogging plattform.

## Demo
You can see Promenade in action on https://www.kaihag.com

## Installation
Download the repository, extract the zip file and place the extracted folder into *your-ghost-directory/content/themes/*
then choose promenade from the theme dropdown list in the ghost admin area (Settings/General).

Finally, change the disqus_shortname var in post.hbs and default.hbs to your own shortname.

## Features
I created this theme for my personal website. Therefore, multiple authors aren't supported yet.
This may change in the future.
