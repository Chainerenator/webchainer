# content/https

Place your cert.pem and cert.key files here to use them when Https is enabled in config.json.

If Https is enabled and cert.pem and cert.key files are not present in this directory, the application will generate new cert.pem and cert.key files upon startup.

Replace those files with your own as soon as possible and don't use them in production.
