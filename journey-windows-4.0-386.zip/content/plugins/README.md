# content/plugins

Place your plugins here.

Read https://github.com/kabukky/journey/wiki/Creating-a-Journey-Plugin for a tutorial on how to create your own Journey plugin.