# content/data

Your Sqlite database file will be placed here by the application.
